﻿/**
 * @Author: Abdullah Ferdous
 * @Date:   27/10/2018
 * @Filename: Location.cs
 */

using System.Collections;
using System.Collections.Generic;

namespace Triangle.Compiler.SyntacticAnalyzer
{
    /// <summary>
    /// A location in a file
    /// </summary>
    public class Location
    {

        //line Number 
        //Line Index;
        private int LineNumber { get; }
        private int LineIndex { get; }

        //constructor method
        public Location(int lineNumber, int lineIndex)
        {
            LineNumber = lineNumber;
            LineIndex = lineIndex;
        }


        //to string method to show line and index number
        public override string ToString()
        {
            return string.Format($"Line Number={LineNumber}  Line Index={LineIndex}");
        }
    }
}
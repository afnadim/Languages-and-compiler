/**
 * @Author: Abdullah Ferdous
 * @Date:   27/10/2018
 * @Filename: Scanner.cs
 */


using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace Triangle.Compiler.SyntacticAnalyzer
{
    /// <summary>
    /// Scanner for the triangle language
    /// </summary>
    public class Scanner : IEnumerable<Token>
    {
        /// <summary>
        /// The file being read from
        /// </summary>
        private SourceFile source;

        /// <summary>
        /// The characters currently in the token being constructed
        /// </summary>
        private StringBuilder currentSpelling;

        /// <summary>
        /// Whether the reader has reached the end of the source file
        /// </summary>
        private bool atEndOfFile = false;



        /// <summary>
        /// Whether to perform debugging
        /// </summary>
        public bool Debug { get; set; }



        /// <summary>
        /// Lookup table of reserved words used to screen tokens
        /// </summary>
        private static ImmutableDictionary<string, TokenKind> ReservedWords { get; } =
            Enumerable.Range((int)TokenKind.Begin, (int)TokenKind.While)
            .Cast<TokenKind>()
            .ToImmutableDictionary(kind => kind.ToString().ToLower(), kind => kind);



        /// <summary>
        /// Creates a new scanner
        /// </summary>
        /// <param name="source">The file to read the characters from</param>
        public Scanner(SourceFile source)
        {
            this.source = source;
            this.source.Reset();
            currentSpelling = new StringBuilder();
        }



        /// <summary>
        /// Returns the tokens in the source file
        /// </summary>
        /// <returns>The sequence of tokens that are found in the source code</returns>
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        /// <summary>
        /// Returns the tokens in the source file
        /// </summary>
        /// <returns>The sequence of tokens that are found in the source code</returns>
        public IEnumerator<Token> GetEnumerator()
        {
            while (!atEndOfFile)
            {
                currentSpelling.Clear();
                ScanWhiteSpace();

                Location startLocation = source.Location;
                TokenKind kind = ScanToken();
                Location endLocation = source.Location;
                SourcePosition position = new SourcePosition(startLocation, endLocation);

                Token token = new Token(kind, currentSpelling.ToString(), position);

                if (kind == TokenKind.EndOfText)
                    atEndOfFile = true;

                if (Debug)
                    Console.WriteLine(token);

                yield return token;
            }

        }



        /// <summary>
        /// Skips over any whitespace
        /// </summary>
        private void ScanWhiteSpace()
        {
            while (source.Current == '!' || source.Current == ' ' || source.Current == '\t' || source.Current == '\n')
            {
                ScanSeparator();
            }
        }
        /// <summary>
        /// Skips a single separator
        /// </summary>
        private void ScanSeparator()
        {
            switch (source.Current)
            {
                //move next if there is a white space
                case ' ':
                    source.MoveNext();
                    break;
                //move next if the new line found
                case '\n':
                    source.MoveNext();
                    break;
                //skip rest of the line if comment found
                case '!':
                    source.SkipRestOfLine();
                    break;
                //move next if the tabs found
                case '\t':
                    source.MoveNext();
                    break;
            }

        }



        /// <summary>
        /// Gets the next token in the file
        /// </summary>
        /// <returns>The type of the next token</returns>
        private TokenKind ScanToken()
        {

            //checking for identifier and reserve words
            if (char.IsLetter(source.Current))
            {

                TakeIt();

                while (char.IsLetterOrDigit(source.Current) || source.Current == '_')
                {
                    TakeIt();
                }

                if (ReservedWords.TryGetValue(currentSpelling.ToString(), out TokenKind reservedWordType))
                    return reservedWordType;

                return TokenKind.Identifier;

            }

            //checking for digits and reserve words
            else if (char.IsDigit(source.Current))
            {
                TakeIt();
                while (char.IsDigit(source.Current))
                {
                    TakeIt();
                }
                return TokenKind.IntLiteral;
            }

            else if (IsOperator(source.Current))
            {

                TakeIt();
                return TokenKind.Operator;
            }

            //checking for charlerals
            if (source.Current == '\'')
            {
                TakeIt();
                if (IsGraphic(source.Current))
                {
                    TakeIt();
                    if (source.Current == '\'')
                    {
                        TakeIt();
                        return TokenKind.CharLiteral;
                    }
                    TakeIt();
                    return TokenKind.Error;
                }
                TakeIt();
                return TokenKind.Error;
            }

            //checking for other tokens

            switch (source.Current)
            {

                case ';':
                    TakeIt();
                    return TokenKind.Semicolon;

                case '~':
                    TakeIt();
                    return TokenKind.Is;

                //checking for colons and becomes
                case ':':
                    TakeIt();
                    if (source.Current == '=')
                    {
                        TakeIt();
                        return TokenKind.Becomes;
                    }
                    return TokenKind.Colon;

                case '?':
                    TakeIt();
                    return TokenKind.QuestionMark;

                case '_':
                    TakeIt();
                    return TokenKind.Underscore;

                case '.':
                    TakeIt();
                    return TokenKind.Dot;

                case ',':
                    TakeIt();
                    return TokenKind.Comma;

                case '(':
                    TakeIt();
                    return TokenKind.LeftBracket;

                case ')':
                    TakeIt();
                    return TokenKind.RightBracket;


                case default(char):
                    // We have reached the end of the file
                    return TokenKind.EndOfText;


                default:
                    // We encountered something we weren't expecting
                    TakeIt();
                    return TokenKind.Error;

            }
        }

        /// <summary>
        /// Appends the current character to the current token, and gets the next character from the source program
        /// </summary>
        private void TakeIt()
        {
            currentSpelling.Append(source.Current);
            source.MoveNext();
        }



        /// <summary>
        /// Checks whether a character is an operator
        /// </summary>
        /// <param name="c">The character to check</param>
        /// <returns>True if and only if the character is an operator in the language</returns>
        private static bool IsOperator(char c)
        {
            switch (c)
            {
                case '+':
                case '-':
                case '*':
                case '/':
                case '=':
                case '<':
                case '>':

                    return true;
                default:
                    return false;
            }
        }

        //checks whether the charecter is a graphics

        private static bool IsGraphic(char c)
        {
            if (char.IsLetterOrDigit(c) || IsOperator(c))
            {
                return true;
            }


            switch (c)
            {
                case '.':
                case '!':
                case '?':
                case '_':
                case ' ':

                    return true;
                default:
                    return false;
            }
        }

        private static bool Isquotation(char c)
        {
            switch (c)
            {
                case '\'':
                    return true;
                default:
                    return false;
            }
        }

    }
}


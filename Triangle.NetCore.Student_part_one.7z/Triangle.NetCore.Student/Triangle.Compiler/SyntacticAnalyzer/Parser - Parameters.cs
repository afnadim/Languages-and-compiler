﻿/**
 * @Author: Abdullah Ferdous
 * @Date:   27/10/2018
 * @Filename: Parser - Parameters.cs
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace Triangle.Compiler.SyntacticAnalyzer
{
    public partial class Parser
    {

        void ParseParameters()
        {
            Console.WriteLine("parsing Parameters      "+"            "+ "["+tokens.Current.Spelling+"}"+ "       "+tokens.Current.Position.ToString());
            ParseParameter();
            while (tokens.Current.Kind == TokenKind.Comma)
            {
                AcceptIt();
                ParseParameter();
            }


        }
        void ParseParameter()
        {

            System.Console.WriteLine("Parsing single parameter" + "         " +"[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
           // Console.WriteLine(tokens.Current.Position.ToString());
            if (tokens.Current.Kind == TokenKind.Var)
                
            {
                AcceptIt();
                ParseIdentifier();
                



            }
            else
            {
                ParseExpression();
            }

        }
    }
}



                
    


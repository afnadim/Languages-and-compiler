/**
 * @Author: John Isaacs <john>
 * @Date:   10-Oct-172017
 * @Filename: Parser - Terminals.cs
 * @Last modified by:   john
 * @Last modified time: 19-Oct-172017
 */



namespace Triangle.Compiler.SyntacticAnalyzer
{
    public partial class Parser
    {

        ///////////////////////////////////////////////////////////////////////////////
        //
        // TERMINALS
        //
        ///////////////////////////////////////////////////////////////////////////////

        /**
         * Parses an identifier, and constructs a leaf AST to represent it.
         */

        void ParseIntLiteral()
        {
            System.Console.WriteLine("Parsing IntLiteral      " + "           " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            Accept(TokenKind.IntLiteral);
        }

        void ParseCharLiterals()
        {
            System.Console.WriteLine("parsing charLiterals      " + "         " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            Accept(TokenKind.CharLiteral);
           

        }



        void ParseOperator()
        {
            System.Console.WriteLine("Parsing Operator      " + "         " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            Accept(TokenKind.Operator);
           
            
            

        }


        void ParseIdentifier()
        {
            System.Console.WriteLine("parsing identifier     " + "           " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            Accept(TokenKind.Identifier);   

        }
    }

    }


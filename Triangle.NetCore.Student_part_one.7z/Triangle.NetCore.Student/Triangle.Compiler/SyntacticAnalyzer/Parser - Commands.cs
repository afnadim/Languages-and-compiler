/**
 * @Author: Abdullah Ferdous
 * @Date:   27/10/2018
 * @Filename: Parser - Commands.cs
 */

namespace Triangle.Compiler.SyntacticAnalyzer
{
    public partial class Parser
    {
        ///////////////////////////////////////////////////////////////////////////////
        //
        // COMMANDS
        //
        ///////////////////////////////////////////////////////////////////////////////


        /// Parses the command 
        void ParseCommand()
        {
            System.Console.WriteLine("parsing command      " + "          " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            ParseSingleCommand();
            while (tokens.Current.Kind == TokenKind.Semicolon)
            {
                AcceptIt();
                ParseSingleCommand();
                break;
            }
        }



        /// Parses the single command

        void ParseSingleCommand()
        {
            System.Console.WriteLine("parsing single command" + "           " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            switch (tokens.Current.Kind)
            {

                case TokenKind.Identifier:
                    {
                        ParseIdentifier();
                        if (tokens.Current.Kind == TokenKind.Becomes)
                        {
                            Accept(TokenKind.Becomes);
                            ParseExpression();
                            break;

                        }
                        else if (tokens.Current.Kind == TokenKind.LeftBracket)
                        {
                            AcceptIt();
                            ParseParameters();
                            Accept(TokenKind.RightBracket);
                            break;

                        }
                        break;
                    }

                case TokenKind.If:
                    AcceptIt();
                    ParseExpression();
                    Accept(TokenKind.Then);
                    ParseSingleCommand();
                    Accept(TokenKind.Else);
                    ParseSingleCommand();
                    break;

                case TokenKind.While:
                    AcceptIt();
                    ParseExpression();
                    Accept(TokenKind.Do);
                    ParseSingleCommand();
                    break;

                case TokenKind.Let:
                    AcceptIt();
                    ParseDeclaration();
                    Accept(TokenKind.In);
                    ParseSingleCommand();
                    break;

                case TokenKind.Begin:
                    AcceptIt();
                    ParseCommand();
                    Accept(TokenKind.End);
                    break;


                    //we dont need a default error section for commands
                    //default:
                    //System.Console.WriteLine("error");
                    //break;

            }
        }


    }



}

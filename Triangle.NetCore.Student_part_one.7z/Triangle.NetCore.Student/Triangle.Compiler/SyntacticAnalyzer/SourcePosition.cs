﻿/**
 * @Author: Abdullah Ferdous
 * @Date:   27/10/2018
 * @Filename SourcePosition.cs
 */


using System;

namespace Triangle.Compiler.SyntacticAnalyzer
{
    /// <summary>
    /// A range of locations in a file
    /// </summary>
    public class SourcePosition
    {
        /// <summary>
        /// Creates a new file range location
        /// </summary>
        ///<param name="startLocation">The starting location of the range</param>
        /// <param name="endLocation">The ending location of the range</param>
        /// 
        // public Location StartLocation;
        // public Location EndLocation;

        public Location StartLocation { get; set; }
        public Location EndLocation { get; set; }


        public SourcePosition(Location startLocation, Location endLocation)
        {
            StartLocation = startLocation;
            EndLocation = endLocation;
        }

        //tostring method
        public override string ToString()
        {
            return string.Format($"Start Position={StartLocation}  End Position={EndLocation}");
        }









    }
}
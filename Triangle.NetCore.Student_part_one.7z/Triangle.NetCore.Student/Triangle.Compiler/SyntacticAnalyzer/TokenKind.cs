/**
 * @Author: Abdullah Ferdous
 * @Date:   27/10/2018
 * @Filename: Parser - TokenKind.cs
 */

namespace Triangle.Compiler.SyntacticAnalyzer
{
    /// <summary>
    /// Types of token in the source language
    /// </summary>
    public enum TokenKind
    {
        // non-terminals
        IntLiteral, Identifier, Operator, CharLiteral,

        // reserved words - terminals
        Begin, Const, Do, Else, End, If, In, Let, Then, Var, While, skip,

        // punctuation - terminals
        Colon, Semicolon, Becomes, Is, LeftBracket, RightBracket,QuestionMark,Comma,Dot,Underscore,

        // special tokens
        EndOfText, Error

        
       
    }
}



﻿/**
 * @Author: Abdullah Ferdous
 * @Date:   27/10/2018
 * @Filename: Parser - Expressions.cs
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace Triangle.Compiler.SyntacticAnalyzer
{
    public partial class Parser
    {
        //parsing Expression
        void ParseExpression()
        {
            Console.WriteLine("Parsing Expression       " + "          " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            ParseSecondaryExpression();
            if (tokens.Current.Kind == TokenKind.QuestionMark)
            {
                AcceptIt();
                ParseExpression();
                Accept(TokenKind.Colon);
                ParseExpression();
            }
        }

        //Parsing Secondary Expression
        void ParseSecondaryExpression()
        {
            System.Console.WriteLine("Parsing Secondary Expression" + "         " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            ParsePrimaryExpression();
            while (tokens.Current.Kind == TokenKind.Operator)
            {
                AcceptIt();

                ParsePrimaryExpression();
            }
        }


        //Parsing Primary Expressions
        void ParsePrimaryExpression()
        {

            System.Console.WriteLine("Parsing Primary Expressions" + "          " + "[" + tokens.Current.Spelling + "}" + "       " + tokens.Current.Position.ToString());
            switch (tokens.Current.Kind)
            {

                case (TokenKind.IntLiteral):
                    {
                        ParseIntLiteral();
                        break;
                    }

                case (TokenKind.CharLiteral):
                    {
                        //ParseDeclaration();
                        ParseCharLiterals();
                        break;


                    }
                case (TokenKind.Identifier):
                    {
                        AcceptIt();
                       // ReportError(tokens.Current, TokenKind.Identifier);
                        //if (tokens.Current.Spelling != TokenKind.Identifier.ToString())
                        //{
                            //System.Console.WriteLine("Error in Expression      " + tokens.Current.Position.ToString()+ "          " + "    We have this token   " +"["+ tokens.Current.Spelling +"]"+ "we was expecting  " + "["+TokenKind.Identifier+"]");
                        //}
                        if (tokens.Current.Kind == TokenKind.LeftBracket)
                        {
                            AcceptIt();
                            ParseParameters();
                            Accept(TokenKind.RightBracket);
                        }
                        break;
                    }
                case (TokenKind.Operator):
                    {
                        AcceptIt();
                        if (tokens.Current.Spelling != TokenKind.Operator.ToString())
                        ParsePrimaryExpression();

                        break;
                    }
                case (TokenKind.LeftBracket):
                    {
                        AcceptIt();
                        if (tokens.Current.Spelling != TokenKind.Operator.ToString())                  
                        ParseExpression();
                        Accept(TokenKind.RightBracket);
                        //ReportError(tokens.Current, TokenKind.RightBracket);
                        break;

                    }

                default:
                    System.Console.WriteLine("Error in Expression     " + "          " + tokens.Current.Position.ToString());
                    //report the error and move to the next token
                    //increment errorCount
                    errorCount++;
                    tokens.MoveNext();
                    break;

            }
        }
    }



}








/**
 * @Author: Abdullah Ferdous
 * @Date:   27/10/2018
 * @Filename: Programs.cs
 */

namespace Triangle.Compiler.SyntacticAnalyzer
{
    public partial class Parser
    {

        ///////////////////////////////////////////////////////////////////////////////
        //
        // PROGRAMS
        //
        ///////////////////////////////////////////////////////////////////////////////


        public void ParseProgram()
        {
                System.Console.WriteLine("parsing Program");
                tokens.MoveNext();
                
                ParseCommand();
        }
    }
}

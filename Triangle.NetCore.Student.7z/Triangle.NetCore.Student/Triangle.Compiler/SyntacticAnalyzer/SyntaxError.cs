using System;

namespace Triangle.Compiler.SyntacticAnalyzer
{
    class SyntaxError : Exception
    {
        
    }
}